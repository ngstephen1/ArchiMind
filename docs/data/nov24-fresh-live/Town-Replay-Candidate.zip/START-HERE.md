# Fresh Town replay candidate

This SQLite database contains both archived revisions of project
1a3f1aff-0c41-4900-902f-34dc54050fda. The accepted layout is revision 1.
Revision 2 moves the bedroom writing chair 0.300 m. The archive contains
the two saved revisions and their input hashes.

From a configured ArchiMind checkout with Town dependencies installed, start
one launcher using a writable copy of the extracted database.

```bash
replay_dir=$(mktemp -d)
cp /path/to/Town-Replay.sqlite3 "$replay_dir/Town-Replay.sqlite3"
ARCHIMIND_ENABLE_OPENAI_STUDIO=0 ARCHIMIND_ENABLE_CODEX_ADVISOR=0 \
  TOWN_PORT=8852 TOWN_EDITOR_PORT=8853 TOWN_DB="$replay_dir/Town-Replay.sqlite3" \
  .venv/bin/python scripts/run_town.py
```

Open [revision 1](http://127.0.0.1:8852/?project=1a3f1aff-0c41-4900-902f-34dc54050fda&revision=1)
and [revision 2](http://127.0.0.1:8852/?project=1a3f1aff-0c41-4900-902f-34dc54050fda&revision=2).
The evidence and environment setup are documented in [the replay guide](https://github.com/ngstephen1/ArchiMind/tree/98c80efaef1e820a7ce3945b7811d14f2dd6b783/docs/data/nov24-fresh-live).

Verify the extracted files with `shasum -a 256 -c SHA256SUMS.txt`. This is a
pre-release replay. The final release declaration is separate.
